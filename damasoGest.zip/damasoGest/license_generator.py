"""
Helper to generate a license key for a given machine ID.

Run:
    python license_manager.py --gen-keys      # ONE TIME: creates keypair
    # paste the printed PUBLIC KEY into license_manager.py

Then to issue licenses:
    python license_generator.py

Or interactively:
    python license_manager.py
"""
import license_manager

# The private key MUST exist as license_private.pem next to this script.
if __name__ == '__main__':
    machine_id = input("Machine ID: ").strip()
    expiry = input("Expiry (e.g. 2026-12-31, 30d, 2h): ").strip()
    if not machine_id or not expiry:
        print("Erro: campos vazios")
        raise SystemExit(1)
    key = license_manager.generate_license_key(machine_id, expiry)
    print("\nChave de licença:")
    print(key)